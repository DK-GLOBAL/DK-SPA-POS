// DK SPA POS cloud API: one function, ?a=login|signup|claim|put|pull|ack
const crypto = require('crypto');
const { SUPABASE_URL: U, SUPABASE_SERVICE_ROLE_KEY: KEY, SUPABASE_JWT_SECRET: SEC, ADMIN_SETUP_CODE: SETUP } = process.env;
const MK = 'dkspa1', TP = 'dkspa_t_', RP = 'req_';
const db = async (p, o = {}) => {
  const r = await fetch(U + '/rest/v1/' + p, { ...o, headers: { apikey: KEY, Authorization: 'Bearer ' + KEY, 'Content-Type': 'application/json', ...(o.headers || {}) } });
  const t = await r.text(); if (!r.ok) throw new Error(t); return t ? JSON.parse(t) : null;
};
const get = async k => { const r = await db('kv?select=v&k=eq.' + encodeURIComponent(k)); return r && r[0] ? r[0].v : null; };
const put = (k, v) => db('kv?on_conflict=k', { method: 'POST', headers: { Prefer: 'resolution=merge-duplicates,return=minimal' }, body: JSON.stringify({ k, v, updated_at: new Date().toISOString() }) });
const sig = s => crypto.createHmac('sha256', SEC).update(s).digest('base64url');
const mk = sc => { const b = Buffer.from(JSON.stringify({ sc, exp: Date.now() + 12 * 36e5 })).toString('base64url'); return b + '.' + sig(b); };
const ver = h => {
  const [b, s] = String(h || '').replace('Bearer ', '').split('.'); if (!b || !s) return null;
  const a = Buffer.from(sig(b)), c = Buffer.from(s); if (a.length !== c.length || !crypto.timingSafeEqual(a, c)) return null;
  const p = JSON.parse(Buffer.from(b, 'base64url')); return p.exp > Date.now() ? p.sc : null;
};
const str = (v, n) => String(v == null ? '' : v).slice(0, n);
const rnd = () => crypto.randomBytes(16).toString('hex');

module.exports = async (req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  try {
    if (req.method !== 'POST') return res.status(405).json({ err: 'method' });
    if (!U || !KEY || !SEC) return res.status(500).json({ err: 'env' });
    const a = req.query.a, b = req.body || {}, sc = ver(req.headers.authorization);

    if (a === 'login') {
      const M = await get(MK); if (!M) return res.json({ err: 'nomaster' });
      const em = str(b.email, 200).toLowerCase(), pw = str(b.pw, 200);
      if ((M.users || []).some(u => u.role === 'platform' && u.email.toLowerCase() === em && u.pw && u.pw === pw)) {
        const rows = await db('kv?select=k,v&k=like.' + TP + '*');
        return res.json({ token: mk('P'), scope: 'P', master: M, tenants: Object.fromEntries((rows || []).map(r => [r.k, r.v])) });
      }
      for (const r of M.tenants || []) {
        const d = await get(TP + r.id);
        if (d && (d.users || []).some(x => x.email.toLowerCase() === em && x.pw === pw)) {
          const slim = { ...M, tenants: [r], reqs: [], leads: [], snaps: [], log: [], fails: {}, otps: [],
            users: (M.users || []).filter(u => u.role === 'platform').map(u => ({ ...u, pw: rnd(), rc: '' })) };
          return res.json({ token: mk(r.id), scope: r.id, master: slim, tenants: { [TP + r.id]: d } });
        }
      }
      const q = (M.reqs || []).find(x => x.email === em && x.pw === pw && x.status !== 'approved');
      if (!q) { const rows = await db('kv?select=v&k=eq.' + RP + encodeURIComponent(em)); if (rows && rows[0] && rows[0].v.pw === pw) return res.json({ err: 'pending' }); }
      return res.json({ err: q ? (q.status === 'rejected' ? 'rejected' : 'pending') : 'bad' });
    }

    if (a === 'signup') {
      const q = b.req || {}, em = str(q.email, 200).toLowerCase();
      if (!em.includes('@') || !q.spa || !q.owner || str(q.pw, 200).length < 8) return res.json({ err: 'invalid' });
      const M = await get(MK);
      const used = M && ((M.users || []).some(u => u.email.toLowerCase() === em) || (M.reqs || []).some(x => x.email === em) || (M.tenants || []).some(t => (t.email || '').toLowerCase() === em));
      if (used || await get(RP + em)) return res.json({ err: 'dup' });
      await put(RP + em, { id: rnd().slice(0, 7), spa: str(q.spa, 120), owner: str(q.owner, 120), email: em, phone: str(q.phone, 20), loc: str(q.loc, 200),
        pw: str(q.pw, 200), pin: str(q.pin, 12), logo: str(q.logo, 400000), status: 'pending', agr: '', date: str(q.date, 10) });
      return res.json({ ok: 1 });
    }

    if (a === 'claim') { // one-time: move the admin's existing browser data to the cloud
      if (!SETUP || b.code !== SETUP) return res.json({ err: 'badcode' });
      if (await get(MK)) return res.json({ err: 'exists' });
      const m = b.master, em = str(b.email, 200).toLowerCase();
      if (!m || !(m.users || []).some(u => u.role === 'platform' && u.email.toLowerCase() === em && u.pw && u.pw === b.pw)) return res.json({ err: 'badcreds' });
      await put(MK, m);
      for (const k of Object.keys(b.tenants || {})) if (k.startsWith(TP)) await put(k, b.tenants[k]);
      return res.json({ token: mk('P'), scope: 'P' });
    }

    if (!sc) return res.status(401).json({ err: 'auth' });

    if (a === 'put') {
      const k = str(b.key, 80);
      if (!(sc === 'P' ? (k === MK || k.startsWith(TP)) : k === TP + sc) || typeof b.value !== 'object' || !b.value) return res.status(403).json({ err: 'forbidden' });
      await put(k, b.value); return res.json({ ok: 1 });
    }
    if (sc !== 'P') return res.status(403).json({ err: 'forbidden' });
    if (a === 'pull') { const rows = await db('kv?select=v&k=like.' + RP + '*'); return res.json({ reqs: (rows || []).map(r => r.v) }); }
    if (a === 'ack') {
      for (const e of (b.emails || []).slice(0, 50)) await db('kv?k=eq.' + RP + encodeURIComponent(str(e, 200).toLowerCase()), { method: 'DELETE' });
      return res.json({ ok: 1 });
    }
    return res.status(404).json({ err: 'action' });
  } catch (e) { return res.status(500).json({ err: 'server', msg: String(e.message).slice(0, 200) }); }
};
