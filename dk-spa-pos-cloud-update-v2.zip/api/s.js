// DK SPA POS cloud API (one function): ?a=login|signup|claim|put|pull|ack|otpreq|otpuse|recover
const crypto = require('crypto');
const { SUPABASE_URL: U, SUPABASE_SERVICE_ROLE_KEY: KEY, SUPABASE_JWT_SECRET: SEC, ADMIN_SETUP_CODE: SETUP } = process.env;
const MK = 'dkspa1', TP = 'dkspa_t_', RP = 'req_', FP = 'fail_', KEEP = '\u0001keep', HR = /^h\$[0-9a-f]{32}\$[0-9a-f]{128}$/;
const db = async (p, o = {}) => {
  const r = await fetch(U + '/rest/v1/' + p, { ...o, headers: { apikey: KEY, Authorization: 'Bearer ' + KEY, 'Content-Type': 'application/json', ...(o.headers || {}) } });
  const t = await r.text(); if (!r.ok) throw new Error(t); return t ? JSON.parse(t) : null;
};
const get = async k => { const r = await db('kv?select=v&k=eq.' + encodeURIComponent(k)); return r && r[0] ? r[0].v : null; };
const put = (k, v) => db('kv?on_conflict=k', { method: 'POST', headers: { Prefer: 'resolution=merge-duplicates,return=minimal' }, body: JSON.stringify({ k, v, updated_at: new Date().toISOString() }) });
const del = k => db('kv?k=eq.' + encodeURIComponent(k), { method: 'DELETE' });
// tokens
const sig = s => crypto.createHmac('sha256', SEC).update(s).digest('base64url');
const mk = p => { const b = Buffer.from(JSON.stringify({ ...p, exp: Date.now() + 12 * 36e5 })).toString('base64url'); return b + '.' + sig(b); };
const ver = h => {
  const [b, s] = String(h || '').replace('Bearer ', '').split('.'); if (!b || !s) return null;
  const a = Buffer.from(sig(b)), c = Buffer.from(s); if (a.length !== c.length || !crypto.timingSafeEqual(a, c)) return null;
  const p = JSON.parse(Buffer.from(b, 'base64url')); return p.exp > Date.now() ? p : null;
};
// passwords: scrypt hashes, format h$<salt>$<hash>
const rnd = () => crypto.randomBytes(16).toString('hex');
const hash = p => { const s = rnd(); return 'h$' + s + '$' + crypto.scryptSync(String(p), s, 64).toString('hex'); };
const vfy = (p, h) => { if (!p || !HR.test(h || '')) return false; const [, s, x] = h.split('$'); return crypto.timingSafeEqual(crypto.scryptSync(String(p), s, 64), Buffer.from(x, 'hex')); };
const sealPw = (p, o) => p === KEEP || p == null ? (HR.test(o || '') ? o : hash(rnd())) : p === '' ? '' : HR.test(p) ? p : HR.test(o || '') && vfy(p, o) ? o : hash(p);
const sealRc = (p, o) => p === KEEP || p == null ? (HR.test(o || '') ? o : '') : p === '' ? '' : HR.test(p) ? p : (p = String(p).toUpperCase(), HR.test(o || '') && vfy(p, o) ? o : hash(p));
const sealUsers = (us, old) => (us || []).map(u => { const o = (old || []).find(x => x.id === u.id) || {}; return { ...u, pw: sealPw(u.pw, o.pw), rc: sealRc(u.rc, o.rc) }; });
const redUsers = us => (us || []).map(u => ({ ...u, pw: u.pw ? KEEP : '', rc: u.rc ? KEEP : '' }));
const weak = n => n.length < 8 || !/[a-zA-Z]/.test(n) || !/\d/.test(n);
const str = (v, n) => String(v == null ? '' : v).slice(0, n);
// throttling (5 wrong tries -> 5 minute lock)
const locked = async k => { const f = await get(FP + k); return f && f.until > Date.now() ? Math.ceil((f.until - Date.now()) / 6e4) : 0; };
const bad = async (k, max) => { const f = (await get(FP + k)) || { n: 0 }; f.n++; if (f.n >= max) { f.until = Date.now() + 3e5; f.n = 0; } await put(FP + k, f); };
const clr = k => del(FP + k);
// otps: keep server copies, incoming status changes win by id
const mergeO = (old, inc) => { const m = new Map((old || []).map(o => [o.id, o])); (inc || []).forEach(o => m.set(o.id, o)); return [...m.values()].filter(o => o.exp > Date.now() - 864e5); };
const locate = async (M, em) => { for (const r of M.tenants || []) { const d = await get(TP + r.id); const u = d && (d.users || []).find(x => x.email.toLowerCase() === em); if (u) return { r, d, u }; } return null; };
const mgr = u => u.role === 'manager' || (u.perms || []).includes('users');

module.exports = async (req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  try {
    if (req.method !== 'POST') return res.status(405).json({ err: 'method' });
    if (!U || !KEY || !SEC) return res.status(500).json({ err: 'env' });
    const a = req.query.a, b = req.body || {}, T = ver(req.headers.authorization), sc = T && T.sc;

    if (a === 'login') {
      const M = await get(MK); if (!M) return res.json({ err: 'nomaster' });
      const em = str(b.email, 200).toLowerCase(), pw = str(b.pw, 200), lk = await locked(em);
      if (lk) return res.json({ err: 'locked', mins: lk });
      const pa = (M.users || []).find(u => u.role === 'platform' && u.email.toLowerCase() === em && vfy(pw, u.pw));
      if (pa) {
        await clr(em);
        const rows = await db('kv?select=k,v&k=like.' + TP + '*');
        const master = { ...M, users: redUsers(M.users).map(u => u.id === pa.id ? { ...u, pw } : u) };
        return res.json({ token: mk({ sc: 'P', uid: pa.id, mg: 1 }), scope: 'P', mg: 1, master,
          tenants: Object.fromEntries((rows || []).map(r => [r.k, { ...r.v, users: redUsers(r.v.users), otps: [] }])) });
      }
      for (const r of M.tenants || []) {
        const d = await get(TP + r.id), u = d && (d.users || []).find(x => x.email.toLowerCase() === em && vfy(pw, x.pw));
        if (!u) continue;
        await clr(em); const mg = mgr(u) ? 1 : 0;
        const slim = { ...M, tenants: [r], reqs: [], leads: [], snaps: [], log: [], fails: {}, otps: [], users: (M.users || []).filter(x => x.role === 'platform').map(x => ({ ...x, pw: rnd(), rc: '' })) };
        const td = { ...d, users: redUsers(d.users).map(x => x.id === u.id ? { ...x, pw } : x), otps: mg ? d.otps || [] : [] };
        return res.json({ token: mk({ sc: r.id, uid: u.id, mg }), scope: r.id, mg, master: slim, tenants: { [TP + r.id]: td } });
      }
      const q = (M.reqs || []).find(x => x.email === em && x.status !== 'approved' && vfy(pw, x.pw)), rq = await get(RP + em);
      if (q) return res.json({ err: q.status === 'rejected' ? 'rejected' : 'pending' });
      if (rq && vfy(pw, rq.pw)) return res.json({ err: 'pending' });
      await bad(em, (M.users || []).some(u => u.role === 'platform' && u.email.toLowerCase() === em) ? 10 : 5);
      return res.json({ err: 'bad' });
    }

    if (a === 'signup') {
      const q = b.req || {}, em = str(q.email, 200).toLowerCase();
      if (!em.includes('@') || !q.spa || !q.owner || str(q.pw, 200).length < 8) return res.json({ err: 'invalid' });
      const M = await get(MK);
      const used = M && ((M.users || []).some(u => u.email.toLowerCase() === em) || (M.reqs || []).some(x => x.email === em) || (M.tenants || []).some(t => (t.email || '').toLowerCase() === em) || await locate(M, em));
      if (used || await get(RP + em)) return res.json({ err: 'dup' });
      await put(RP + em, { id: rnd().slice(0, 7), spa: str(q.spa, 120), owner: str(q.owner, 120), email: em, phone: str(q.phone, 20), loc: str(q.loc, 200),
        pw: hash(str(q.pw, 200)), pin: str(q.pin, 12), logo: str(q.logo, 400000), status: 'pending', agr: '', date: str(q.date, 10) });
      return res.json({ ok: 1 });
    }

    if (a === 'claim') { // one-time: move the admin's existing browser data to the cloud (hashing every password)
      if (!SETUP || b.code !== SETUP) return res.json({ err: 'badcode' });
      if (await get(MK)) return res.json({ err: 'exists' });
      const m = b.master, em = str(b.email, 200).toLowerCase(), pa = m && (m.users || []).find(u => u.role === 'platform' && u.email.toLowerCase() === em && u.pw && u.pw === b.pw);
      if (!pa) return res.json({ err: 'badcreds' });
      await put(MK, { ...m, users: sealUsers(m.users), reqs: (m.reqs || []).map(q => ({ ...q, pw: sealPw(q.pw) })) });
      for (const k of Object.keys(b.tenants || {})) if (k.startsWith(TP)) await put(k, { ...b.tenants[k], users: sealUsers(b.tenants[k].users) });
      return res.json({ token: mk({ sc: 'P', uid: pa.id, mg: 1 }), scope: 'P', mg: 1 });
    }

    // ---- public password help ----
    if (a === 'otpreq') {
      const em = str(b.email, 200).toLowerCase(), M = await get(MK);
      if (M && !(await locked('otpreq:' + em))) {
        await bad('otpreq:' + em, 5); const L = await locate(M, em);
        if (L && L.u.role !== 'platform' && L.u.role !== 'manager' && L.u.st !== 'suspended') {
          L.d.otps = (L.d.otps || []).filter(x => x.uid !== L.u.id || x.status !== 'open');
          L.d.otps.push({ id: rnd().slice(0, 7), uid: L.u.id, name: L.u.name, email: L.u.email, otp: String(100000 + crypto.randomInt(900000)), exp: Date.now() + 6e5, tries: 0, status: 'open' });
          await put(TP + L.r.id, L.d);
        }
      }
      return res.json({ ok: 1 });
    }
    if (a === 'otpuse') {
      const em = str(b.email, 200).toLowerCase(), M = await get(MK), n = str(b.pw, 200); if (!M) return res.json({ err: 'invalid' });
      const lk = await locked('otp:' + em); if (lk) return res.json({ err: 'locked', mins: lk });
      const L = await locate(M, em), o = L && (L.d.otps || []).find(x => x.uid === L.u.id && x.status === 'open');
      if (!o || o.exp < Date.now()) return res.json({ err: 'invalid' });
      if (str(b.otp, 10).trim() !== o.otp) { o.tries = (o.tries || 0) + 1; if (o.tries >= 3) o.status = 'used'; await put(TP + L.r.id, L.d); await bad('otp:' + em, 6); return res.json({ err: o.tries >= 3 ? 'toomany' : 'wrong' }); }
      if (weak(n)) return res.json({ err: 'weak' });
      L.u.pw = hash(n); L.u.mc = 0; o.status = 'used'; await put(TP + L.r.id, L.d); await clr('otp:' + em); await clr(em);
      return res.json({ ok: 1 });
    }
    if (a === 'recover') {
      const em = str(b.email, 200).toLowerCase(), M = await get(MK), n = str(b.pw, 200); if (!M) return res.json({ err: 'badrc' });
      const lk = await locked('rc:' + em); if (lk) return res.json({ err: 'locked', mins: lk });
      const u = (M.users || []).find(x => x.role === 'platform' && x.email.toLowerCase() === em);
      if (!u || !vfy(str(b.rc, 40).trim().toUpperCase(), u.rc)) { await bad('rc:' + em, 5); return res.json({ err: 'badrc' }); }
      if (weak(n)) return res.json({ err: 'weak' });
      u.pw = hash(n); u.rc = ''; await put(MK, M); await clr('rc:' + em); await clr(em);
      return res.json({ ok: 1 });
    }

    // ---- signed-in actions ----
    if (!T) return res.status(401).json({ err: 'auth' });
    if (a === 'put') {
      const k = str(b.key, 80), v = b.value;
      if (!(sc === 'P' ? (k === MK || k.startsWith(TP)) : k === TP + sc) || typeof v !== 'object' || !v) return res.status(403).json({ err: 'forbidden' });
      const old = (await get(k)) || {};
      if (k === MK) { v.users = sealUsers(v.users, old.users); v.reqs = (v.reqs || []).map(q => ({ ...q, pw: sealPw(q.pw, ((old.reqs || []).find(x => x.id === q.id) || {}).pw) })); }
      else if (sc === 'P' || T.mg) { v.users = sealUsers(v.users, old.users); v.otps = mergeO(old.otps, v.otps); }
      else { // staff/reception can only change their own password and tenant data, never users, rights or OTPs
        const me = (v.users || []).find(x => x.id === T.uid);
        v.users = (old.users || []).map(o => o.id === T.uid && me ? { ...o, pw: sealPw(me.pw, o.pw), mc: me.mc } : o); v.otps = old.otps || [];
      }
      await put(k, v); return res.json({ ok: 1 });
    }
    if (a === 'pull') {
      if (sc === 'P') { const rows = await db('kv?select=v&k=like.' + RP + '*'); return res.json({ reqs: (rows || []).map(r => r.v) }); }
      if (T.mg) { const d = await get(TP + sc); return res.json({ otps: ((d && d.otps) || []).filter(x => x.status === 'open' && x.exp > Date.now()) }); }
      return res.status(403).json({ err: 'forbidden' });
    }
    if (a === 'ack' && sc === 'P') { for (const e of (b.emails || []).slice(0, 50)) await del(RP + str(e, 200).toLowerCase()); return res.json({ ok: 1 }); }
    return res.status(404).json({ err: 'action' });
  } catch (e) { return res.status(500).json({ err: 'server', msg: String(e.message).slice(0, 200) }); }
};
